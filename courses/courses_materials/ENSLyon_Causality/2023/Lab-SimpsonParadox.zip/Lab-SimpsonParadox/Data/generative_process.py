np.random.seed(1)
z = np.random.normal(size=2000)
np.random.seed(4)
x = 0.8 * z + 0.2 * np.random.normal(size=2000)
np.random.seed(2)
y = 0.3 * z + 0.6 * x + 0.1 * np.random.normal(size=2000)
np.random.seed(3)
w = 3 * x + 3 * y + 0.1 * np.random.normal(size=2000)
data1 = pd.DataFrame(np.array([z, x, y, w]).T, columns=["Z", "X", "Y", "W"])

data1.to_csv("./Data/data1.csv")

