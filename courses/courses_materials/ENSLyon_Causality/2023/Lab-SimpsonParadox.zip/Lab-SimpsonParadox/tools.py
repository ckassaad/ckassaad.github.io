import numpy as np
import networkx as nx
import matplotlib.pyplot as plt


def plot_graph(g, title=''):
    """
    :param g: Networkx DiGraph
    :param title: "Title of the Figure"
    """
    pos = nx.circular_layout(g)
    plt.title(title)
    nx.draw(g, pos, with_labels=True, font_weight='bold', node_size=1000, node_shape="s")
    plt.show()
